library(testthat)
library(jsmodule)
library(shinytest)

test_check("jsmodule")
